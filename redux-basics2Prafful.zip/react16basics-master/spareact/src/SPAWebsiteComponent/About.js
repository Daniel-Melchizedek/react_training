import React from 'react';

class About extends React.Component {
    
    render() { 
        return (
            <div>
                <h2>About</h2>
                <p>it is fun to be the FSD!</p>
            </div>

          );
    }
}
 
export default About;