import React from 'react';

class NotFound extends React.Component {
  
    render() { 
        return ( 
            <div>
            Page not found. Pl. go to the home page or get in touch with web master.
            </div>
         );
    }
}
 
export default NotFound;