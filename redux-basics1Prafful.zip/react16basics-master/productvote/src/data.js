const feedback = [
    {
        id:1,
        title:"Project Mr. Bean",
        description:"One of the richest comedian on the globe!!!",
        url:"http://www.google.com",
        imageUrl:"../images/1.jpg",
        avatarUrl:"../images/icon/1.jpg",
        vote:56
    },
    {
        id:2,
        title:"Project Full Stack",
        description:"Fundamental of Digital Engineering!!!",
        url:"http://www.google.com",
        imageUrl:"../images/2.gif",
        avatarUrl:"../images/icon/2.jpg",
        vote:22
    },
    {
        id:3,
        title:"Party Tonight",
        description:"Group in ITC Chola!!!",
        url:"http://www.google.com",
        imageUrl:"../images/4.gif",
        avatarUrl:"../images/icon/3.jpg",
        vote:45
    },
    {
        id:4,
        title:"Make In India",
        description:"Manufacture in India at Cheap price!!!",
        url:"http://www.google.com",
        imageUrl:"../images/4.gif",
        avatarUrl:"../images/icon/4.jpg",
        vote:58
    },
    {
        id:5,
        title:"Dumbo Mumbo",
        description:"dumbo mumbo jumbo kumbo...!!!",
        url:"http://www.google.com",
        imageUrl:"../images/5.jpg",
        avatarUrl:"../images/icon/1.jpg",
        vote:61
    },
    {
        id:6,
        title:"Idea To product",
        description:"Explore the process of product engineering!!!",
        url:"http://www.google.com",
        imageUrl:"../images/6.jpg",
        avatarUrl:"../images/icon/2.jpg",
        vote:51
    },
    {
        id:7,
        title:"Bahubali",
        description:"Nice Masala Movie!!!",
        url:"http://www.google.com",
        imageUrl:"../images/1.jpg",
        avatarUrl:"../images/icon/3.jpg",
        vote:32
    },
    {
        id:8,
        title:"Programming",
        description:"Bread and Butter winner for all programmers!!!",
        url:"http://www.google.com",
        imageUrl:"../images/4.gif",
        avatarUrl:"../images/icon/4.jpg",
        vote:71
    }
]

export default feedback