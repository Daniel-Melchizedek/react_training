import React from 'react';

class Home extends React.Component {
    
    render() { 
        return (
            <div>
                <h2>Home</h2>
                <p>Being at home is such a good feeling</p>
            </div>

          );
    }
}
 
export default Home;