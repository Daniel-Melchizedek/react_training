import ReactDOM from 'react-dom'
import React from 'react';
import SpaWebsite from './SPAWebsiteComponent/SpaWebsite';



ReactDOM.render(<SpaWebsite></SpaWebsite>,
                document.getElementById("root"))