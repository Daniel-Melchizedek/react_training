import React from 'react';

class FeedbackDescription extends React.Component {

    render() { 
        return (  
            <div>
                <ul>
                    <li>Description 1</li>
                    <li>Description 2</li>
                    <li>Description 3</li>
                    <li>Description 4</li>
                </ul>
            </div>
        );
    }
}
 
export default FeedbackDescription;