//Reducers are functions which will return array of 
//JSON objects

const allUsers = function(){
    return [
        {
            "id": 1,
            "location":"Chennai"
        },
        {
            "id": 2,
            "location":"Bengaluru"
        },
        {
            "id": 3,
            "location":"Kochi"
        },
        {
            "id": 4,
            "location":"Pune"
        } 
    ]
}

export default allUsers