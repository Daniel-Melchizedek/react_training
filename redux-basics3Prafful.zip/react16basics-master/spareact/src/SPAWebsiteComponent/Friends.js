import React from 'react';

class Friends extends React.Component {
    
    render() { 
        return (
            <div>
                <h2>Friends</h2>
                <p>They are like good old days. But, new ones are always there!!!</p>
            </div>

          );
    }
}
 
export default Friends;